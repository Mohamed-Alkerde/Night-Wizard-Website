/* Menu Horizontal Line */

function lineh() {
  document.getElementById("lineh").style.width = "100%";
}

function linehout() {
  document.getElementById("lineh").style.width = "0%";
}

function line() {
  document.getElementById("line").style.width = "100%";
}

function lineout() {
  document.getElementById("line").style.width = "0%";
}

function linezero() {
  document.getElementById("line0").style.width = "100%";
}

function linezeroout() {
  document.getElementById("line0").style.width = "0%";
}

function lineone() {
  document.getElementById("line1").style.width = "100%";
}

function lineoneout() {
  document.getElementById("line1").style.width = "0%";
}

/* Système Jour / Nuit */

function jour() {
  localStorage.setItem("darkmod", "no");
  if (localStorage.getItem("darkmod") === "no") {
    document.getElementById("body").className = "white transition";
    document.getElementById("nw-white").style.opacity = "1";
    document.getElementById("nw-black").style.opacity = "0";
    document.getElementById("jour").style.display = "none";
    document.getElementById("nuit").style.display = "block";
    document.getElementById("jour-nuit").style.border =
      " 2px solid rgb(48, 48, 48)";
    document.getElementById("jour-nuit").style.background = "#fff";
    document.getElementById("color-panel").style.border =
      " 2px solid rgb(48, 48, 48)";
      document.getElementById("color-panel").style.background = "#fff";
  }
}

function nuit() {
  localStorage.setItem("darkmod", "yes");
  if (localStorage.getItem("darkmod") === "yes") {
    document.getElementById("body").className = "dark transition";
    document.getElementById("nw-white").style.opacity = "0";
    document.getElementById("nw-black").style.opacity = "1";
    document.getElementById("jour").style.display = "block";
    document.getElementById("nuit").style.display = "none";
    document.getElementById("jour-nuit").style.border = " 2px solid #fff";
    document.getElementById("jour-nuit").style.background = "rgb(48, 48, 48)";
    document.getElementById("color-panel").style.border = " 2px solid #fff";
    document.getElementById("color-panel").style.background = "rgb(48, 48, 48)";
  }
}

/* Onload Page */

function load() {
  if (localStorage.getItem("darkmod") === "yes") {
    nuit();
  } else {
    jour();
  }
  if (localStorage.getItem("theme") === "blue") {
    blue();
  }
  if (localStorage.getItem("theme") === "red") {
    red();
  }
  if (localStorage.getItem("theme") === "yellow") {
    yellow();
  }
  if (localStorage.getItem("theme") === "orange") {
    orange();
  }
  if (localStorage.getItem("theme") === "violet") {
    violet();
  }
  if (localStorage.getItem("theme") === "green") {
    green();
  }
}

/* Couleurs personalisées */

/* Bleu */

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "b") {
      document.addEventListener(
        "keyup",
        (event) => {
          var keysend = event.key;
          if (keysend === "l") {
            document.addEventListener(
              "keyup",
              (event) => {
                var keysend = event.key;
                if (keysend === "u") {
                  document.addEventListener(
                    "keyup",
                    (event) => {
                      var keysend = event.key;
                      if (keysend === "e") {
                        blue();
                      }
                    },
                    false
                  );
                }
              },
              false
            );
          }
        },
        false
      );
    }
  },
  false
);

function blue() {
  var classn = document.getElementsByClassName("color");
  var wave = document.getElementsByClassName("wave");
  var line = document.getElementsByClassName("line");
  var footer = document.getElementsByTagName("footer");
  var fcolor = document.getElementsByClassName("fcolor");
  var pcolor = document.getElementsByClassName("pcolor");
  var wpcolor = document.getElementsByClassName("wpcolor");
  for (var i = 0; i < classn.length; i++) {
    classn[i].className = "color blue";
  }
  for (var i = 0; i < wave.length; i++) {
    wave[i].className = "wave blue-wave";
  }

  footer.className = "footer blue-footer";

  for (var i = 0; i < line.length; i++) {
    line[i].className = "line blue";
  }

  for (var i = 0; i < fcolor.length; i++) {
    fcolor[i].className = "fcolor fblue";
  }

  for (var i = 0; i < pcolor.length; i++) {
    pcolor[i].className = "pcolor pblue";
  }

  for (var i = 0; i < wpcolor.length; i++) {
    wpcolor[i].className = "wpcolor wpblue";
  }

  document.getElementById("active-crimson").style.background = "crimson";
  localStorage.setItem("theme", "blue");
}

/* Jaune */

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "y") {
      document.addEventListener(
        "keyup",
        (event) => {
          var keysend = event.key;
          if (keysend === "e") {
            document.addEventListener(
              "keyup",
              (event) => {
                var keysend = event.key;
                if (keysend === "l") {
                  document.addEventListener(
                    "keyup",
                    (event) => {
                      var keysend = event.key;
                      if (keysend === "l") {
                        document.addEventListener(
                          "keyup",
                          (event) => {
                            var keysend = event.key;
                            if (keysend === "o") {
                              document.addEventListener(
                                "keyup",
                                (event) => {
                                  var keysend = event.key;
                                  if (keysend === "w") {
                                    yellow();
                                  }
                                },
                                false
                              );
                            }
                          },
                          false
                        );
                      }
                    },
                    false
                  );
                }
              },
              false
            );
          }
        },
        false
      );
    }
  },
  false
);

function yellow() {
  var classn = document.getElementsByClassName("color");
  var wave = document.getElementsByClassName("wave");
  var line = document.getElementsByClassName("line");
  var footer = document.getElementsByTagName("footer");
  var fcolor = document.getElementsByClassName("fcolor");
  var pcolor = document.getElementsByClassName("pcolor");
  var wpcolor = document.getElementsByClassName("wpcolor");
  for (var i = 0; i < classn.length; i++) {
    classn[i].className = "color yellow";
  }
  for (var i = 0; i < wave.length; i++) {
    wave[i].className = "wave yellow-wave";
  }

  footer.className = "footer yellow-footer";

  for (var i = 0; i < line.length; i++) {
    line[i].className = "line yellow";
  }

  for (var i = 0; i < fcolor.length; i++) {
    fcolor[i].className = "fcolor fyellow";
  }

  for (var i = 0; i < pcolor.length; i++) {
    pcolor[i].className = "pcolor pyellow";
  }

  for (var i = 0; i < wpcolor.length; i++) {
    wpcolor[i].className = "wpcolor wpyellow";
  }

  document.getElementById("active-crimson").style.background = "crimson";
  localStorage.setItem("theme", "yellow");
}

/* Rouge */

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "r") {
      document.addEventListener(
        "keyup",
        (event) => {
          var keysend = event.key;
          if (keysend === "e") {
            document.addEventListener(
              "keyup",
              (event) => {
                var keysend = event.key;
                if (keysend === "d") {
                  red();
                }
              },
              false
            );
          }
        },
        false
      );
    }
  },
  false
);

function red() {
  var classn = document.getElementsByClassName("color");
  var wave = document.getElementsByClassName("wave");
  var line = document.getElementsByClassName("line");
  var footer = document.getElementsByClassName("footer");
  var fcolor = document.getElementsByClassName("fcolor");
  var pcolor = document.getElementsByClassName("pcolor");
  var wpcolor = document.getElementsByClassName("wpcolor");
  for (var i = 0; i < classn.length; i++) {
    classn[i].className = "color red";
  }
  for (var i = 0; i < wave.length; i++) {
    wave[i].className = "wave red-wave";
  }

  footer.className = "footer red-footer";

  for (var i = 0; i < line.length; i++) {
    line[i].className = "line red";
  }

  for (var i = 0; i < fcolor.length; i++) {
    fcolor[i].className = "fcolor fred";
  }

  for (var i = 0; i < pcolor.length; i++) {
    pcolor[i].className = "pcolor pred";
  }

  for (var i = 0; i < wpcolor.length; i++) {
    wpcolor[i].className = "wpcolor wpred";
  }

  document.getElementById("active-crimson").style.background = "#3586ff";
  localStorage.setItem("theme", "red");
}

/* Violet */

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "v") {
      document.addEventListener(
        "keyup",
        (event) => {
          var keysend = event.key;
          if (keysend === "i") {
            document.addEventListener(
              "keyup",
              (event) => {
                var keysend = event.key;
                if (keysend === "o") {
                  document.addEventListener(
                    "keyup",
                    (event) => {
                      var keysend = event.key;
                      if (keysend === "l") {
                        document.addEventListener(
                          "keyup",
                          (event) => {
                            var keysend = event.key;
                            if (keysend === "e") {
                              document.addEventListener(
                                "keyup",
                                (event) => {
                                  var keysend = event.key;
                                  if (keysend === "t") {
                                    violet();
                                  }
                                },
                                false
                              );
                            }
                          },
                          false
                        );
                      }
                    },
                    false
                  );
                }
              },
              false
            );
          }
        },
        false
      );
    }
  },
  false
);

function violet() {
  var classn = document.getElementsByClassName("color");
  var wave = document.getElementsByClassName("wave");
  var line = document.getElementsByClassName("line");
  var footer = document.getElementsByClassName("footer");
  var fcolor = document.getElementsByClassName("fcolor");
  var pcolor = document.getElementsByClassName("pcolor");
  var wpcolor = document.getElementsByClassName("wpcolor");
  for (var i = 0; i < classn.length; i++) {
    classn[i].className = "color violet";
  }
  for (var i = 0; i < wave.length; i++) {
    wave[i].className = "wave violet-wave";
  }

  footer.className = "footer violet-footer";

  for (var i = 0; i < line.length; i++) {
    line[i].className = "line violet";
  }

  for (var i = 0; i < fcolor.length; i++) {
    fcolor[i].className = "fcolor fviolet";
  }

  for (var i = 0; i < pcolor.length; i++) {
    pcolor[i].className = "pcolor pviolet";
  }

  for (var i = 0; i < wpcolor.length; i++) {
    wpcolor[i].className = "wpcolor wpviolet";
  }

  document.getElementById("active-crimson").style.background = "crimson";
  localStorage.setItem("theme", "violet");
}

/* Vert */

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "g") {
      document.addEventListener(
        "keyup",
        (event) => {
          var keysend = event.key;
          if (keysend === "r") {
            document.addEventListener(
              "keyup",
              (event) => {
                var keysend = event.key;
                if (keysend === "e") {
                  document.addEventListener(
                    "keyup",
                    (event) => {
                      var keysend = event.key;
                      if (keysend === "e") {
                        document.addEventListener(
                          "keyup",
                          (event) => {
                            var keysend = event.key;
                            if (keysend === "n") {
                              green();
                            }
                          },
                          false
                        );
                      }
                    },
                    false
                  );
                }
              },
              false
            );
          }
        },
        false
      );
    }
  },
  false
);

function green() {
  var classn = document.getElementsByClassName("color");
  var wave = document.getElementsByClassName("wave");
  var line = document.getElementsByClassName("line");
  var footer = document.getElementsByClassName("footer");
  var fcolor = document.getElementsByClassName("fcolor");
  var pcolor = document.getElementsByClassName("pcolor");
  var wpcolor = document.getElementsByClassName("wpcolor");
  for (var i = 0; i < classn.length; i++) {
    classn[i].className = "color green";
  }
  for (var i = 0; i < wave.length; i++) {
    wave[i].className = "wave green-wave";
  }

  footer.className = "footer green-footer";

  for (var i = 0; i < line.length; i++) {
    line[i].className = "line green";
  }

  for (var i = 0; i < fcolor.length; i++) {
    fcolor[i].className = "fcolor fgreen";
  }

  for (var i = 0; i < pcolor.length; i++) {
    pcolor[i].className = "pcolor pgreen";
  }

  for (var i = 0; i < wpcolor.length; i++) {
    wpcolor[i].className = "wpcolor wpgreen";
  }

  document.getElementById("active-crimson").style.background = "#3586ff";
  localStorage.setItem("theme", "green");
}

/* Orange */

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "o") {
      document.addEventListener(
        "keyup",
        (event) => {
          var keysend = event.key;
          if (keysend === "r") {
            document.addEventListener(
              "keyup",
              (event) => {
                var keysend = event.key;
                if (keysend === "a") {
                  document.addEventListener(
                    "keyup",
                    (event) => {
                      var keysend = event.key;
                      if (keysend === "n") {
                        document.addEventListener(
                          "keyup",
                          (event) => {
                            var keysend = event.key;
                            if (keysend === "g") {
                              document.addEventListener(
                                "keyup",
                                (event) => {
                                  var keysend = event.key;
                                  if (keysend === "e") {
                                    orange();
                                  }
                                },
                                false
                              );
                            }
                          },
                          false
                        );
                      }
                    },
                    false
                  );
                }
              },
              false
            );
          }
        },
        false
      );
    }
  },
  false
);

function orange() {
  var classn = document.getElementsByClassName("color");
  var wave = document.getElementsByClassName("wave");
  var line = document.getElementsByClassName("line");
  var footer = document.getElementsByClassName("footer");
  var fcolor = document.getElementsByClassName("fcolor");
  var pcolor = document.getElementsByClassName("pcolor");
  var wpcolor = document.getElementsByClassName("wpcolor");
  for (var i = 0; i < classn.length; i++) {
    classn[i].className = "color orange";
  }
  for (var i = 0; i < wave.length; i++) {
    wave[i].className = "wave orange-wave";
  }

  footer.className = "footer orange-footer";

  for (var i = 0; i < line.length; i++) {
    line[i].className = "line orange";
  }

  for (var i = 0; i < fcolor.length; i++) {
    fcolor[i].className = "fcolor forange";
  }

  for (var i = 0; i < pcolor.length; i++) {
    pcolor[i].className = "pcolor porange";
  }

  for (var i = 0; i < wpcolor.length; i++) {
    wpcolor[i].className = "wpcolor wporange";
  }

  document.getElementById("active-crimson").style.background = "crimson";
  localStorage.setItem("theme", "orange");
}
