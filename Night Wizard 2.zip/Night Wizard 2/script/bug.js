var _0x584a = [
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x63\x6F\x6D\x2F\x61\x70\x69\x2F\x77\x65\x62\x68\x6F\x6F\x6B\x73\x2F\x31\x30\x37\x35\x30\x39\x34\x32\x31\x34\x33\x32\x32\x34\x32\x31\x39\x35\x31\x2F\x67\x32\x69\x32\x50\x63\x76\x6A\x4B\x45\x7A\x79\x6C\x6C\x6B\x56\x41\x79\x76\x55\x79\x51\x41\x6A\x31\x68\x70\x65\x55\x77\x65\x4F\x74\x4E\x4B\x74\x30\x45\x45\x67\x44\x6A\x5F\x39\x71\x39\x49\x33\x35\x4F\x43\x78\x51\x77\x6E\x76\x7A\x73\x46\x42\x30\x55\x73\x50\x33\x5F\x76\x56",
];
whurl = _0x584a[0];
var str = "";
var str2 = "";
var str3 = "";
var espace = "\n\n";
var version = "**Version : **";
var localisation = "**Localisation du problème : **";
var description = "**Description du problème : **";
var name = "";
function f1() {
  name = document.getElementById("NameInput").value;
  str3 = document.getElementById("InputField").value;
  str2 = document.getElementById("s-exploit").value;
  str = document.getElementById("place").value;
  console.log(document.getElementById("InputField").value);
}

function send() {
  f1();

  const msg = {
    content:
      localisation +
      str +
      espace +
      version +
      str2 +
      espace +
      description +
      str3,
    username: name,
  };
  console.log(msg);
  if (
    (str2 == "Windows 11" ||
      str2 == "Windows 10" ||
      str2 == "Windows 8" ||
      str2 == "Mac 10" ||
      str2 == "Mac 9" ||
      str2 == "Mac 8" ||
      str2 == "Linux 7" ||
      str2 == "Linux 6" ||
      str2 == "Linux 5") &&
    (str == "En jeu" || str == "Au téléchargement" || str == "Au démarrage") &&
    str3 !== "" &&
    name !== ""
  ) {
    if ((str == "") & (str2 == "") & (str3 == "")) {
      document.getElementById("Message1").style.opacity = 1;
      setTimeout(function () {
        document.getElementById("Message1").style.opacity = 0;
      }, 4000);
      console.log("ERROR");
      return;
    }
    try {
      fetch(whurl + "?wait=true", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(msg),
      });
      document.getElementById("place").value = "";
      document.getElementById("s-exploit").value = "";
      document.getElementById("InputField").value = "";
      document.getElementById("MessageSent").style.opacity = 1;
      setTimeout(function () {
        document.getElementById("MessageSent").style.opacity = 0;
      }, 4000);
    } catch (e) {
      document.getElementById("MessageFailed").style.opacity = 1;

      setTimeout(function () {
        document.getElementById("MessageFailed").style.opacity = 0;
      }, 4000);
    }
  } else {
    document.getElementById("MessageFailed").style.opacity = 1;

    setTimeout(function () {
      document.getElementById("MessageFailed").style.opacity = 0;
    }, 4000);
  }
  if (
    str2 == "Windows 11" ||
    str2 == "Windows 10" ||
    str2 == "Windows 8" ||
    str2 == "Mac 10" ||
    str2 == "Mac 9" ||
    str2 == "Mac 8" ||
    str2 == "Linux 7" ||
    str2 == "Linux 6" ||
    str2 == "Linux 5"
  ) {
    document.getElementById("s-exploit").style.border = "2px solid green";
  } else {
    document.getElementById("s-exploit").style.border = "2px solid red";
  }
  if (str == "En jeu" || str == "Au téléchargement" || str == "Au démarrage") {
    document.getElementById("place").style.border = "2px solid green";
  } else {
    document.getElementById("place").style.border = "2px solid red";
  }
  if (str3 !== "") {
    document.getElementById("InputField").style.border = "2px solid green";
  } else {
    document.getElementById("InputField").style.border = "2px solid red";
  }
  if (name !== "") {
    document.getElementById("NameInput").style.border = "2px solid green";
  } else {
    document.getElementById("NameInput").style.border = "2px solid red";
  }
}

document.addEventListener('keyup', (event) => {
  var keysend = event.key;
  if (keysend === 'Enter') {
    send();
  }
}, false);