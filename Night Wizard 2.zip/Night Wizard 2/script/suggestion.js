var _0xe617 = [
  "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x63\x6F\x6D\x2F\x61\x70\x69\x2F\x77\x65\x62\x68\x6F\x6F\x6B\x73\x2F\x31\x30\x37\x37\x36\x36\x34\x36\x35\x37\x39\x39\x30\x34\x38\x38\x30\x37\x35\x2F\x70\x71\x39\x52\x37\x5F\x44\x6B\x36\x55\x38\x78\x35\x55\x4B\x66\x34\x37\x76\x34\x4C\x77\x70\x39\x35\x2D\x36\x46\x6A\x30\x6D\x6F\x4B\x33\x42\x6A\x59\x50\x52\x61\x39\x61\x4D\x53\x68\x63\x51\x4E\x50\x30\x6A\x61\x59\x6F\x72\x38\x72\x4B\x45\x35\x48\x5A\x33\x64\x6F\x51\x72\x55",
];
whurl = _0xe617[0];
var str = "";
var str2 = "";
var espace = "\n\n";
var localisation = "**Partie concernée : **";
var description = "**Description de l'idée : **";
var name = "";
function f1() {
  name = document.getElementById("NameInput").value;
  str2 = document.getElementById("InputField").value;
  str = document.getElementById("place").value;
  console.log(document.getElementById("InputField").value);
}

function send() {
  f1();

  const msg = {
    content: localisation + str + espace + description + str2,
    username: name,
  };
  console.log(msg);
  if (
    (str == "En jeu" ||
      str == "Sur le site web" ||
      str == "Dans le launcher") &&
    str2 !== "" &&
    name !== ""
  ) {
    if ((str == "") & (str2 == "")) {
      document.getElementById("Message1").style.opacity = 1;
      setTimeout(function () {
        document.getElementById("Message1").style.opacity = 0;
      }, 4000);
      console.log("ERROR");
      return;
    }
    try {
      fetch(whurl + "?wait=true", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(msg),
      });
      document.getElementById("place").value = "";
      document.getElementById("InputField").value = "";
      document.getElementById("MessageSent").style.opacity = 1;
      setTimeout(function () {
        document.getElementById("MessageSent").style.opacity = 0;
      }, 4000);
    } catch (e) {
      document.getElementById("MessageFailed").style.opacity = 1;

      setTimeout(function () {
        document.getElementById("MessageFailed").style.opacity = 0;
      }, 4000);
    }
  } else {
    document.getElementById("MessageFailed").style.opacity = 1;

    setTimeout(function () {
      document.getElementById("MessageFailed").style.opacity = 0;
    }, 4000);
  }
  if (
    str == "En jeu" ||
    str == "Sur le site web" ||
    str == "Dans le launcher"
  ) {
    document.getElementById("place").style.border = "2px solid green";
  } else {
    document.getElementById("place").style.border = "2px solid red";
  }
  if (str2 !== "") {
    document.getElementById("InputField").style.border = "2px solid green";
  } else {
    document.getElementById("InputField").style.border = "2px solid red";
  }
  if (name !== "") {
    document.getElementById("NameInput").style.border = "2px solid green";
  } else {
    document.getElementById("NameInput").style.border = "2px solid red";
  }
}

document.addEventListener(
  "keyup",
  (event) => {
    var keysend = event.key;
    if (keysend === "Enter") {
      send();
    }
  },
  false
);
