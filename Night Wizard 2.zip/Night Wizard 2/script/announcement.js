/* Système de filtrage des news */

function filtre() {
  document.getElementById("filtrest").style.display = "none";
  document.getElementById("filtrest2").style.display = "flex";
  document.getElementById("filtrest").style.borderBottom = "2px solid #717171";
  document.getElementById("filtre-2").style.display = "block";
  document.getElementById("filtre-21").style.display = "block";
  document.getElementById("filtre-22").style.display = "block";
  document.getElementById("filtre-23").style.display = "block";
  document.getElementById("filtre").style.height = "auto";
}

function filtreoff() {
  document.getElementById("filtrest").style.display = "flex";
  document.getElementById("filtrest2").style.display = "none";
  document.getElementById("filtrest").style.borderBottom = "none";
  document.getElementById("filtre-2").style.display = "none";
  document.getElementById("filtre-21").style.display = "none";
  document.getElementById("filtre-22").style.display = "none";
  document.getElementById("filtre-23").style.display = "none";
  document.getElementById("filtre").style.height = "0";
}

function news() {
  var changelog = document.getElementsByClassName("changelog");
  var events = document.getElementsByClassName("events");
  var news = document.getElementsByClassName("news");
  for (var i = 0; i < changelog.length; i++) {
    changelog[i].style.display = "none";
  }
  for (var i = 0; i < events.length; i++) {
    events[i].style.display = "none";
  }
  for (var i = 0; i < news.length; i++) {
    news[i].style.display = "flex";
  }
}

function changelog() {
  var changelog = document.getElementsByClassName("changelog");
  var events = document.getElementsByClassName("events");
  var news = document.getElementsByClassName("news");
  for (var i = 0; i < changelog.length; i++) {
    changelog[i].style.display = "flex";
  }
  for (var i = 0; i < events.length; i++) {
    events[i].style.display = "none";
  }
  for (var i = 0; i < news.length; i++) {
    news[i].style.display = "none";
  }
}

function evenement() {
  var changelog = document.getElementsByClassName("changelog");
  var events = document.getElementsByClassName("events");
  var news = document.getElementsByClassName("news");
  for (var i = 0; i < changelog.length; i++) {
    changelog[i].style.display = "none";
  }
  for (var i = 0; i < events.length; i++) {
    events[i].style.display = "flex";
  }
  for (var i = 0; i < news.length; i++) {
    news[i].style.display = "none";
  }
}

function tout() {
  var changelog = document.getElementsByClassName("changelog");
  var events = document.getElementsByClassName("events");
  var news = document.getElementsByClassName("news");
  for (var i = 0; i < changelog.length; i++) {
    changelog[i].style.display = "flex";
  }
  for (var i = 0; i < events.length; i++) {
    events[i].style.display = "flex";
  }
  for (var i = 0; i < news.length; i++) {
    news[i].style.display = "flex";
  }
}

/* Menu Horizontal Line Externe */

function lineh2() {
  document.getElementById("lineh2").style.width = "60.078px";
}

function linehout2() {
  document.getElementById("lineh2").style.width = "0px";
}

function line2() {
  document.getElementById("line2").style.width = "43.859px";
}

function lineout2() {
  document.getElementById("line2").style.width = "0px";
}

function linezero2() {
  document.getElementById("line02").style.width = "34.625px";
}

function linezeroout2() {
  document.getElementById("line02").style.width = "0px";
}

function lineone2() {
  document.getElementById("line12").style.width = "73.031px";
}

function lineoneout2() {
  document.getElementById("line12").style.width = "0px";
}
